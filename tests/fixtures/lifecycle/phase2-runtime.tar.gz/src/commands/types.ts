import type { DaemonStatus } from "../domain/runtime/types.js";
import type { RunnerType } from "../domain/task/index.js";
import type {
  CommandCreateTaskResult,
  CommandListResult,
  CommandAddTaskLinkResult,
  CommandAddTaskRepoTargetResult,
  CommandListTaskLinksResult,
  CommandShowTaskResult,
  CommandCurrentTaskResult,
  CommandRenameTaskResult,
  CommandTaskPrResult,
  CommandLogsResult,
  CommandDiffResult,
  CommandOpenResult,
  CommandChecksResult,
  CommandCommitResult,
} from "../domain/task/index.js";
import type {
  CommandCreateWorkspaceResult,
  CommandCreateRepoResult,
  CommandListReposResult,
  CommandRemoveRepoResult,
  CommandListWorkspacesResult,
  CommandArchiveWorkspaceResult,
  CommandRestoreWorkspaceResult,
  CommandRemoveWorkspaceResult,
} from "../domain/workspace/index.js";
import type { CommandShowContextResult } from "../domain/context/index.js";
import type {
  AgentRuntimeState,
  CommandAgentListResult,
  CommandAgentStatusResult,
  CommandTaskWaitResult,
} from "../domain/agent/index.js";
import type {
  CommandEventListResult,
  CommandEventWatchResult,
  CommandCancelPromptResult,
  CommandListPromptsResult,
  CommandSendAgentPromptResult,
  CommandShowPromptResult,
  CommandWaitPromptResult,
  CommandCreateChildResult,
  CommandListChildrenResult,
  CommandCancelTreeResult,
  CommandValidateFuryResult,
  CommandPlanFuryResult,
  CommandApproveFuryResult,
  CommandRunFuryResult,
  CommandShowFuryResult,
  CommandCancelFuryResult,
  CommandResumeFuryResult,
  CommandStepFuryResult,
  CommandListFuryReviewsResult,
  CommandShowFuryReviewResult,
  CommandActFuryReviewResult,
  CommandWatchFuryResult,
  PromptCommandState,
  PromptDelivery,
} from "../domain/orchestration/index.js";
import type { PromptInput } from "../shell/prompt-commands.js";
import type { CommandOpenFileResult } from "../domain/file/index.js";

export type AppCommand =
  | { kind: "daemonStatus" }
  | { kind: "addWorkspace"; path: string }
  | { kind: "addRepo"; path: string }
  | { kind: "listRepos" }
  | { kind: "removeRepo"; repoId: string }
  | { kind: "listWorkspaces"; archived: boolean }
  | { kind: "archiveWorkspace"; workspaceId: string }
  | { kind: "restoreWorkspace"; workspaceId: string }
  | { kind: "removeWorkspace"; workspaceId: string }
  | { kind: "createTask"; repoId?: string; workspaceId?: string; prompt: string; runner?: RunnerType; operationId?: string }
  | { kind: "createChildTask"; parentTaskId?: string; repoId?: string; workspaceId?: string; prompt: string; runner?: RunnerType; idempotencyKey?: string; operationId?: string }
  | { kind: "listTaskChildren"; taskId?: string }
  | { kind: "cancelTaskTree"; taskId?: string }
  | { kind: "validateFury"; file: string }
  | { kind: "planFury"; file: string; inputs: Record<string, string>; rootTaskId?: string }
  | { kind: "approveFury"; planId: string }
  | { kind: "runFury"; planId: string }
  | { kind: "showFury"; runId: string }
  | { kind: "watchFury"; runId: string; after?: string; format: "human" | "jsonl" }
  | { kind: "cancelFury"; runId: string }
  | { kind: "resumeFury"; runId: string }
  | { kind: "completeFuryStep"; runId: string; stepId: string; output?: { source: "inline"; text: string } | { source: "file"; path: string } | { source: "stdin" } }
  | { kind: "failFuryStep"; runId: string; stepId: string; reason: string }
  | { kind: "listFuryReviews"; runId?: string; state?: string }
  | { kind: "showFuryReview"; reviewId: string }
  | { kind: "actFuryReview"; reviewId: string; action: "approve" | "reject" | "request_changes" | "resubmit"; message?: string }
  | { kind: "listTasks"; repoId?: string; workspaceId?: string }
  | { kind: "currentTask" }
  | { kind: "renameTask"; taskId?: string; title: string }
  | { kind: "addTaskLink"; taskId: string; repoId: string }
  | { kind: "addTaskRepoTarget"; taskId: string; repoId: string }
  | { kind: "listTaskLinks"; taskId: string }
  | { kind: "openFile"; path: string }
  | { kind: "refreshInteractiveState" }
  | { kind: "showTask"; taskId: string }
  | { kind: "showCurrentTask" }
  | { kind: "showTaskPr"; taskId?: string; repoId?: string }
  | { kind: "discoverTaskPr"; taskId?: string; repoId?: string }
  | { kind: "linkTaskPr"; taskId?: string; repoId?: string; pullRequest: string }
  | { kind: "refreshTaskPr"; taskId?: string; repoId?: string }
  | { kind: "unlinkTaskPr"; taskId?: string; repoId?: string; pullRequest: string }
  | { kind: "listAgents"; taskId?: string }
  | { kind: "showAgentStatus"; taskId?: string; tabId?: string }
  | { kind: "waitTask"; taskId?: string; states: AgentRuntimeState[]; tabId?: string; timeoutMs: number }
  | { kind: "listEvents"; taskId?: string; typeGlob?: string; after?: string }
  | { kind: "watchEvents"; taskId?: string; typeGlob?: string; after?: string; format: "human" | "jsonl" }
  | { kind: "sendAgentPrompt"; taskId?: string; tabId?: string; prompt: PromptInput; delivery: PromptDelivery; timeoutMs: number; idempotencyKey?: string }
  | { kind: "showPromptCommand"; commandId: string }
  | { kind: "listPromptCommands"; taskId?: string }
  | { kind: "cancelPromptCommand"; commandId: string }
  | { kind: "waitPromptCommand"; commandId: string; states?: PromptCommandState[]; timeoutMs: number }
  | { kind: "showSelectedTask" }
  | { kind: "streamTaskLogs"; taskId: string }
  | { kind: "streamSelectedTaskLogs" }
  | { kind: "showTaskDiff"; taskId: string }
  | { kind: "showSelectedTaskDiff" }
  | { kind: "openTask"; taskId: string }
  | { kind: "openSelectedTask" }
  | { kind: "runChecks"; taskId: string }
  | { kind: "runSelectedTaskChecks" }
  | { kind: "commitTask"; taskId: string }
  | { kind: "commitSelectedTask" }
  | { kind: "showContext" }
  | { kind: "help" }
  | { kind: "exit" };

export interface CommandHelpResult {
  kind: "help";
  text: string;
}

export interface CommandExitResult {
  kind: "exit";
}

export type {
  CommandCreateTaskResult,
  CommandListResult,
  CommandAddTaskLinkResult,
  CommandAddTaskRepoTargetResult,
  CommandListTaskLinksResult,
  CommandShowTaskResult,
  CommandCurrentTaskResult,
  CommandRenameTaskResult,
  CommandTaskPrResult,
  CommandLogsResult,
  CommandDiffResult,
  CommandOpenResult,
  CommandChecksResult,
  CommandCommitResult,
  CommandCreateWorkspaceResult,
  CommandCreateRepoResult,
  CommandListReposResult,
  CommandRemoveRepoResult,
  CommandListWorkspacesResult,
  CommandArchiveWorkspaceResult,
  CommandRestoreWorkspaceResult,
  CommandRemoveWorkspaceResult,
  CommandShowContextResult,
  AgentRuntimeState,
  CommandAgentListResult,
  CommandAgentStatusResult,
  CommandTaskWaitResult,
  CommandEventListResult,
  CommandEventWatchResult,
  CommandCancelPromptResult,
  CommandListPromptsResult,
  CommandSendAgentPromptResult,
  CommandShowPromptResult,
  CommandWaitPromptResult,
  CommandCreateChildResult,
  CommandListChildrenResult,
  CommandCancelTreeResult,
  CommandValidateFuryResult,
  CommandPlanFuryResult,
  CommandApproveFuryResult,
  CommandRunFuryResult,
  CommandShowFuryResult,
  CommandCancelFuryResult,
  CommandResumeFuryResult,
  CommandStepFuryResult,
  CommandListFuryReviewsResult,
  CommandShowFuryReviewResult,
  CommandActFuryReviewResult,
  CommandWatchFuryResult,
  CommandOpenFileResult,
};

export type CommandResult =
  | DaemonStatus
  | CommandCreateWorkspaceResult
  | CommandCreateRepoResult
  | CommandListReposResult
  | CommandRemoveRepoResult
  | CommandListWorkspacesResult
  | CommandArchiveWorkspaceResult
  | CommandRestoreWorkspaceResult
  | CommandRemoveWorkspaceResult
  | CommandCreateTaskResult
  | CommandCreateChildResult
  | CommandListChildrenResult
  | CommandCancelTreeResult
  | CommandValidateFuryResult
  | CommandPlanFuryResult
  | CommandApproveFuryResult
  | CommandRunFuryResult
  | CommandShowFuryResult
  | CommandCancelFuryResult
  | CommandResumeFuryResult
  | CommandStepFuryResult
  | CommandListFuryReviewsResult
  | CommandShowFuryReviewResult
  | CommandActFuryReviewResult
  | CommandWatchFuryResult
  | CommandAddTaskLinkResult
  | CommandAddTaskRepoTargetResult
  | CommandListTaskLinksResult
  | CommandHelpResult
  | CommandExitResult
  | CommandListResult
  | CommandShowTaskResult
  | CommandCurrentTaskResult
  | CommandRenameTaskResult
  | CommandTaskPrResult
  | CommandAgentListResult
  | CommandAgentStatusResult
  | CommandTaskWaitResult
  | CommandEventListResult
  | CommandEventWatchResult
  | CommandCancelPromptResult
  | CommandListPromptsResult
  | CommandSendAgentPromptResult
  | CommandShowPromptResult
  | CommandWaitPromptResult
  | CommandShowContextResult
  | CommandLogsResult
  | CommandDiffResult
  | CommandOpenResult
  | CommandChecksResult
  | CommandCommitResult
  | CommandOpenFileResult;
