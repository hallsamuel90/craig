import { randomUUID, createHash } from "node:crypto";
import path from "node:path";
import { readPrivateRecord } from "./runtime/records.js";
import { ensureRuntimeRunning } from "./runtime/start.js";
import { submitRuntimeTaskCreate } from "./runtime/task-create-client.js";
import { requireAvailableRuntimeCapabilities } from "./runtime/discovery.js";
import { CraigError } from "../domain/error/index.js";
import {
  cancelTaskTree,
  createChildTask,
  promptCommandService,
  type CommandCancelTreeResult,
  type CommandCreateChildResult,
  type CreateChildInput,
  createRootTask,
} from "../domain/orchestration/index.js";
import { taskService, type CommandCreateTaskResult, type TaskCreationOptions } from "../domain/task/index.js";
import type { CraigPaths } from "../state/craig-paths.js";
import { disposeDaemonSessions, ensureDaemonAgentSession } from "./pty-daemon-orchestration.js";
import { requirePromptCommandWake } from "./prompt-commands.js";
import { buildEmbeddedAgentCommand } from "./agent-command.js";

const INITIAL_PROMPT_TIMEOUT_MS = 60_000;

export async function createChildTaskAndSession(
  paths: CraigPaths,
  input: CreateChildInput,
): Promise<CommandCreateChildResult> {
  await ensureRuntimeRunning(paths);
  if (await readPrivateRecord(path.join(paths.runtimeDir, "control.json"))) {
    const { operationId = input.idempotencyKey ? `child_${createHash("sha256").update(input.parentTaskId).update("\0").update(input.idempotencyKey).digest("hex")}` : randomUUID(), ...request } = input;
    return await submitRuntimeTaskCreate(paths, operationId, { kind: "child", input: request }) as CommandCreateChildResult;
  }
  const notice = await requireAvailableRuntimeCapabilities(paths, ["delegatedLaunch", "orchestration"]);
  const result = await createChildTask(paths, input, { createTask: createDaemonOwnedTask });
  return notice ? { ...result, warnings: [`${notice} Creating this session delays legacy migration.`] } : result;
}

export async function createRootTaskAndSession(
  paths: CraigPaths,
  repoIdOrWorkspaceId: string,
  prompt: string,
  options: TaskCreationOptions = {},
): Promise<CommandCreateTaskResult> {
  await ensureRuntimeRunning(paths);
  if (await readPrivateRecord(path.join(paths.runtimeDir, "control.json"))) {
    const { operationId = randomUUID(), runner, workspaceId, owningWorkspaceId, allowLinkedProjectRepo } = options;
    return await submitRuntimeTaskCreate(paths, operationId, { kind: "root", targetId: repoIdOrWorkspaceId, prompt,
      options: { ...(runner ? { runner } : {}), ...(workspaceId ? { workspaceId } : {}), ...(owningWorkspaceId ? { owningWorkspaceId } : {}), ...(allowLinkedProjectRepo !== undefined ? { allowLinkedProjectRepo } : {}) } }) as CommandCreateTaskResult;
  }
  const notice = await requireAvailableRuntimeCapabilities(paths, ["delegatedLaunch"]);
  const result = await createRootTask(paths, repoIdOrWorkspaceId, prompt, {
    ...options,
    launchProvisioned: (task, environment) => launchDaemonTask(paths, task, environment, false),
  });
  return notice ? { ...result, warnings: [`${notice} Creating this session delays legacy migration.`] } : result;
}

async function createDaemonOwnedTask(
  paths: CraigPaths,
  repoId: string,
  prompt: string,
  options: TaskCreationOptions = {},
): Promise<CommandCreateTaskResult> {
  return taskService.createTask(paths, repoId, prompt, {
    ...options,
    markStartedAfterLaunch: false,
    launchProvisioned: (task, environment) => launchDaemonTask(paths, task, environment, true),
  });
}

async function launchDaemonTask(
  paths: CraigPaths,
  task: Awaited<ReturnType<typeof taskService.getTask>>,
  environment?: Record<string, string>,
  durableInitialPrompt = false,
): Promise<void> {
  const agentTab = task.ptyTabs.find((tab) => tab.kind === "agent");
  if (!agentTab) throw new Error(`Task ${task.id} is missing its agent PTY tab.`);
  try {
    await ensureDaemonAgentSession(paths, {
      taskId: task.id,
      tabId: agentTab.id,
      cwd: task.worktreePath,
      command: buildEmbeddedAgentCommand(
        durableInitialPrompt ? agentTab.command : task.runnerSession.command,
        agentTab.runner ?? task.runner,
      ),
      ...(environment ? { env: environment } : {}),
    });
    if (!durableInitialPrompt) return;
    const initial = await promptCommandService.create(paths, {
      taskId: task.id,
      agentTabId: agentTab.id,
      prompt: { source: "inline", text: task.prompt.value },
      delivery: "when-ready",
      timeoutMs: INITIAL_PROMPT_TIMEOUT_MS,
      idempotencyKey: `task-start:${task.id}`,
      actor: { type: "system", component: "orchestration-supervisor" },
    });
    await requirePromptCommandWake(paths, initial.command.id);
  } catch (error) {
    await disposeDaemonSessions(paths, [agentTab.id]);
    throw error;
  }
}

export async function cancelTaskTreeAndSessions(
  paths: CraigPaths,
  taskId: string,
  capabilityId?: string,
): Promise<CommandCancelTreeResult> {
  const tasks = (await taskService.listTasks(paths, { includeClosed: true })).tasks;
  const subtreeIds = new Set([taskId]);
  let changed = true;
  while (changed) {
    changed = false;
    for (const task of tasks) {
      if (task.parentTaskId && subtreeIds.has(task.parentTaskId) && !subtreeIds.has(task.id)) {
        subtreeIds.add(task.id);
        changed = true;
      }
    }
  }
  const tabIds = tasks
    .filter((task) => subtreeIds.has(task.id))
    .flatMap((task) => task.ptyTabs.map((tab) => tab.id));
  try {
    const result = await cancelTaskTree(paths, taskId, capabilityId);
    if (!await disposeDaemonSessions(paths, tabIds)) {
      throw new CraigError("PARTIAL_RESULT", "The task tree was closed, but Craig could not stop its agent sessions. Retry cancellation after the daemon is available.", {
        retryable: true, details: { taskId, persisted: true, sessionsStopped: false },
      });
    }
    return result;
  } catch (error) {
    if (error instanceof CraigError && error.code === "PARTIAL_RESULT" && error.details.persisted === true) {
      await disposeDaemonSessions(paths, tabIds);
    }
    throw error;
  }
}
