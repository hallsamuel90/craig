import { realpathSync } from "node:fs";
import { resolveRuntimeCompatibility } from "./runtime/compatibility.js";
import { createHash } from "node:crypto";
import { tmpdir } from "node:os";
import path from "node:path";

import type { CraigPaths } from "../state/craig-paths.js";

export const PTY_DAEMON_PROTOCOL_VERSION = 10;

export function isCompatiblePtyDaemonProtocol(version: number | undefined): boolean {
  return resolveRuntimeCompatibility(version === undefined ? {} : { protocolVersion: version }).compatible;
}

export function getPtyDaemonEndpoint(paths: CraigPaths): { socketPath: string; pidPath: string } {
  const workspaceHash = createHash("sha256").update(realpathSync(paths.workspaceRoot)).digest("hex").slice(0, 16);
  return {
    socketPath: path.join(tmpdir(), `craig-${workspaceHash}.sock`),
    pidPath: path.join(paths.runtimeDir, "pty-daemon.pid"),
  };
}
