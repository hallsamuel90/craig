import type { PreviewFeatureId, RunnerType } from "../domain/config/index.js";

export interface CraigUiRuntime {
  version: 1;
  pendingTaskCreateOperationId?: string | null;
  runtimeViewClient?: { clientId: string; proof: string; ownerPid: number };
  selectedRepoId: string | null;
  selectedWorkspaceId: string | null;
  selectedTaskId: string | null;
  selectedPtyTabId?: string | null;
  inputMode?: "control" | "terminal";
  focusedRegion?: "tasks" | "center" | "inspector" | "actions" | "tabs";
  activeTab?: string;
  preferredPtyTabKind?: "agent" | "terminal";
  inspectorSection?: "task" | "checks" | "pr" | "setup-run" | "actions" | "next-action";
  inspectionMode?: "diff" | "files" | "review" | "checks" | "actions";
  openInspectionKind?: "file" | "diff" | null;
  selectedFileTreePath?: string | null;
  selectedFilePath?: string | null;
  selectedDiffPath?: string | null;
  collapsedFileTreePaths?: string[];
  selectedActionId?: "commit" | "push" | "refresh-checks" | "close-task";
  selectedRunner?: RunnerType;
  ignoredUpdateVersion?: string;
  seenPreviewIds?: PreviewFeatureId[];
  readAgentActivityAt?: Record<string, number>;
  updatedAt: string;
}
